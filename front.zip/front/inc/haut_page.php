<?php require 'connexion.php';?> 

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Lien bootstrap CDN -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!-- Lien fontawasome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <!-- Lien Googlefont -->
    <link href="https://fonts.googleapis.com/css?family=Cinzel|Diplomata" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Fredericka+the+Great" rel="stylesheet">  
    <!-- CK Editor 4. -->
    <script src="ckeditor/ckeditor.js"></script>
    <!-- Lien pour la page authentification -->
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    
    <!-- Mon style CSS -->
    <link rel="stylesheet" href="css/style.css">
    
    
    
    <title>SiteCV</title>
</head>
<body>
    <div class="container-fluid">