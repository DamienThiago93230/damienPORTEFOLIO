<?php require 'connexion.php';?>

 
  <!-- Footer--> 
  
      <hr>
      <footer class="text-center p-2">
            <div class="row mx-auto">
                <div class="col-lg-4">
                <h4 style="color: gold">Me contacter</h4>
                    <p><strong style="color: #f47f33">Téléphone :</strong> 06-18-12-25-64</p>
                    <p><strong style="color: #f47f33">Email:</strong> santo.damien@hotmail.com</p>
                </div>
                <div class="col-lg-4">
                <h4 style="color: gold">Réseaux</h4>
                    <p class="reseaux">
                        <a style="color: white" href="https://github.com/DamienThiago93230" target="_blank"><i class="fab fa-github"></i></a>
                        <a href="https://www.linkedin.com/feed/" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                    </p>
                </div>
                <div class="col-lg-4">
                <h4 style="color: gold">Message</h4>
                    <a class="reseaux" href="messages.php" style="color:wheat"><i class="fas fa-envelope"></i></a>
                </div>
            </div><!-- Fin .row -->
                
            <div class="col-lg-12">
                <p style="color: #f47f33">Copyright &copy; Mon siteCV - 2018</p>
            </div>
      </footer>
  </div> <!-- Fin container-fluid -->
  
  <!-- lien bootstrap -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em" crossorigin="anonymous"></script>
</body>
</html>